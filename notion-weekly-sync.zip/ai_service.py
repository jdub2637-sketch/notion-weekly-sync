import logging
from typing import List
import re

logger = logging.getLogger(__name__)

class AIService:
    def __init__(self, provider: str, gemini_api_key: str = "", openai_api_key: str = ""):
        self.provider = provider.lower()
        self.gemini_api_key = gemini_api_key
        self.openai_api_key = openai_api_key

    def extract_action_items(self, meeting_notes: str, user_name: str, user_role: str = "마케터") -> List[str]:
        """
        회의록에서 사용자가 이번 주(Short-term) 동안 수행해야 할 일을 리스트 형태로 추출합니다.
        """
        prompt = self._build_prompt(meeting_notes, user_name, user_role)

        if self.provider == "gemini":
            raw_result = self._call_gemini(prompt)
        elif self.provider == "openai":
            raw_result = self._call_openai(prompt)
        else:
            raise ValueError(f"지원하지 않는 AI 제공자입니다: {self.provider}")

        tasks = self._parse_tasks(raw_result)
        logger.info(f"AI가 {len(tasks)}개의 할 일 항목을 추출했습니다.")
        return tasks

    def _build_prompt(self, meeting_notes: str, user_name: str, user_role: str) -> str:
        name_hint = f"대상자 이름: {user_name}" if user_name else "대상자 이름: 명시되지 않음 (마케팅 담당자 업무 위주)"
        role_hint = f"직무/역할: {user_role}" if user_role else ""

        return f"""당신은 회의록에서 주간 실행 과제(Action Items)를 날카롭게 추출하는 프로젝트 매니저 AI입니다.

아래의 [마케팅팀 주간회의록]을 정밀하게 분석하여, 이번 1주일 동안 수행해야 할 단기 실행 과제(WorkNote Short-term)를 정리해주세요.

[대상자 정보]
- {name_hint}
- {role_hint}

[추출 기준]
1. 회의록 내에서 대상자({user_name or '마케터'})의 이름, 담당 업무, 멘션, 또는 역할({user_role})과 연관된 모든 실행 과제(Action Items)를 우선 추출합니다.
2. 담당자가 명확히 분리되어 있지 않더라도, 이번 주 마케팅팀의 핵심 실행 업무 및 확인 사항 중 대상자가 담당할 만한 업무를 포함합니다.
3. 각 항목은 노션 표(Table)의 1개 셀에 들어갈 수 있도록 '간결하고 명확한 실행형 문장'으로 작성하세요. (예: [프로모션] 블랙프라이데이 사전 예약 페이지 오픈 및 QA)
4. 중요도나 마감일이 회의록에 있다면 괄호 안에 함께 명시하세요. (예: 인스타그램 주간 콘텐츠 3건 발행 (수요일까지))
5. 서론, 인사말, 번호 매기기(#, 1., 2.), 마크다운 코드블록 등 부가 텍스트는 일체 출력하지 마세요.
6. 오직 한 줄에 할 일 1개씩, 줄바꿈(엔터)으로만 구분하여 출력하세요.

[마케팅팀 주간회의록]
{meeting_notes}
"""

    def _call_gemini(self, prompt: str) -> str:
        import google.generativeai as genai
        genai.configure(api_key=self.gemini_api_key)
        # 안정적인 gemini-1.5-flash 또는 gemini-2.5-flash
        model = genai.GenerativeModel("gemini-1.5-flash")
        logger.info("Google Gemini API를 호출하여 회의록 분석 중...")
        response = model.generate_content(prompt)
        return response.text if response else ""

    def _call_openai(self, prompt: str) -> str:
        from openai import OpenAI
        client = OpenAI(api_key=self.openai_api_key)
        logger.info("OpenAI API (gpt-4o-mini)를 호출하여 회의록 분석 중...")
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": "You are a helpful assistant that extracts actionable to-do items from meeting notes."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.3
        )
        return response.choices[0].message.content or ""

    def _parse_tasks(self, raw_text: str) -> List[str]:
        lines = raw_text.strip().split("\n")
        tasks = []
        for line in lines:
            line = line.strip()
            # 마크다운 불렛, 숫자, 대시 등 정리
            line = re.sub(r"^[\d\.\-\*\•\>\s]+", "", line).strip()
            if line and not line.startswith("```"):
                tasks.append(line)
        return tasks
