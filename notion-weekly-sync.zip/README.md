# 📅 Notion 주간 회의록 -> WorkNote 할 일 자동화 (Notion Weekly Tasks Sync)

매주 월요일마다 진행되는 **"마케팅팀 주간회의"** 페이지의 회의록 및 메모를 AI가 자동으로 분석하여, 1주일 동안 내가 수행해야 할 핵심 단기 과제를 **"Daily Life"** 페이지의 **"WorkNote(Short-term)"** 1열 표(Table)에 자동으로 정리해 주는 자동화 프로그램입니다.

---

## 🌟 주요 기능
1. **Control + E (인라인 코드) 지정 텍스트 100% 정밀 추출 (추천)**:
   - 회의 중 본인이 해야 할 일이나 메모에 `Ctrl + E` (코딩 서식) 처리를 해두면, AI 오탐 없이 내가 지정한 항목만 정확하게 쏙쏙 뽑아냅니다. (이 모드는 AI API 키조차 필요 없어 100% 무료 & 세팅이 초간단합니다!)
2. **스마트 AI 회의록 분석 (선택 옵션)**:
   - 회의록 전체 맥락을 Google Gemini 또는 OpenAI GPT가 분석하여 내 이름/역할에 매칭되는 실행 과제(Action Items)를 자동 추출할 수도 있습니다.
3. **Notion 1열 일반 표(Table) 자동 생성 및 행 추가**:
   - `Daily Life` 페이지 내 `WorkNote(Short-term)` 섹션 아래에 1열 표가 있다면 새 행들을 즉시 추가하고, 없다면 `[이번 주 할 일 (YYYY-MM-DD)]` 헤더를 가진 새 1열 표를 자동 생성합니다.
4. **GitHub Actions 100% 무료 자동 스케줄링**:
   - 매주 월요일 오전(설정 시간)에 컴퓨터를 켜두지 않아도 클라우드에서 완전 자동으로 실행됩니다.
   - 원할 때 GitHub 웹에서 버튼 하나(`Run workflow`)로 즉시 수동 실행할 수도 있습니다.

---

## 🛠 사전 준비 사항 (3분 소요)

### 1. Notion API 통합 토큰 발급
1. [Notion My Integrations](https://www.notion.so/my-integrations) 페이지에 접속하여 로그인합니다.
2. **'+ 새 API 통합 만들기(New integration)'** 클릭
   - 이름: `주간 업무 자동화` (원하는 이름)
   - 연결된 워크스페이스 선택
3. 생성이 완료되면 **'프라이빗 API 통합 토큰'** (`secret_...` 형태)을 복사해 둡니다.

### 2. 노션 페이지에 통합 권한 부여 (필수!)
노션 API가 페이지를 읽고 쓰려면 권한을 주어야 합니다:
1. **"마케팅팀 주간회의"** 페이지로 이동 -> 우측 상단 **`···`** 클릭 -> **`연결(Connect to)`** 또는 **`연결 추가`** -> 방금 만든 통합(`주간 업무 자동화`) 선택
2. **"Daily Life"** 페이지로 이동 -> 동일하게 우측 상단 **`···`** 클릭 -> **`연결(Connect to)`** -> 방금 만든 통합 선택

### 3. 페이지 ID (또는 페이지 URL) 복사
- **마케팅팀 주간회의** 페이지 링크 복사:
  - 예: `https://www.notion.so/myteam/Marketing-Weekly-Meeting-2b9921e6955a40a8a68b7dc3f639ea07`
  - URL 전체를 그대로 넣으셔도 스크립트가 32자리 ID를 자동으로 추출합니다!
- **Daily Life** 페이지 링크 복사:
  - 예: `https://www.notion.so/myworkspace/Daily-Life-1234567890abcdef1234567890abcdef`

### 4. AI API 키 발급 (무료 Google Gemini 추천)
- **Google Gemini API (추천, 무료)**:
  - [Google AI Studio](https://aistudio.google.com/)에서 'Get API key' 클릭 후 복사
- 또는 **OpenAI API**:
  - [OpenAI 플랫폼](https://platform.openai.com/api-keys)에서 키 발급

---

## 🚀 설정 및 실행 방법

### 방법 1: GitHub Actions로 매주 월요일 자동 실행 (추천!)

1. 이 프로젝트 코드를 본인의 **GitHub 저장소(Repository)**에 업로드(Push)합니다.
2. GitHub 저장소의 **`Settings` -> `Secrets and variables` -> `Actions`** 메뉴로 이동합니다.
3. **`New repository secret`** 버튼을 눌러 다음 값들을 추가합니다:

| 시크릿 이름 (Name) | 설명 | 기본값 / 예시 |
| :--- | :--- | :--- |
| `NOTION_TOKEN` | 노션 API 통합 토큰 (필수) | `secret_abc123...` |
| `NOTION_SOURCE_PAGE_ID` | 마케팅팀 주간회의 페이지 URL 또는 ID (필수) | `https://www.notion.so/...` |
| `NOTION_TARGET_PAGE_ID` | Daily Life 페이지 URL 또는 ID (필수) | `https://www.notion.so/...` |
| `EXTRACT_MODE` | 추출 모드 (`code`: Ctrl+E 텍스트만, `auto`: 코딩텍스트 우선/AI대체, `ai`: 전체AI) | `code` (기본값) |
| `TARGET_SECTION_TITLE` | 대상 섹션 제목 | `WorkNote(Short-term)` |
| `MY_NAME` | 회의록에서 찾을 본인 이름 (AI 모드 시 필요) | `홍길동` |
| `MY_ROLE` | 본인 직무/역할 (AI 모드 시 필요) | `퍼포먼스 마케터` |
| *(선택) `AI_PROVIDER`* | AI 제공자 (`gemini` 또는 `openai`) | `gemini` |
| *(선택) `GEMINI_API_KEY`* | AI 모드 사용 시 Gemini 키 (code 모드 시 불필요) | `AIzaSy...` |
| *(선택) `OPENAI_API_KEY`* | OpenAI를 사용할 경우의 키 | `sk-...` |

4. **즉시 실행 테스트**:
   - 저장소 상단의 **`Actions`** 탭 클릭 -> 왼쪽의 **`Weekly Notion Meeting Action Items Sync`** 선택 -> **`Run workflow`** 버튼 클릭!
   - 30초 내에 녹색 체크 표시와 함께 노션 Daily Life 페이지에 표가 채워집니다.
5. **실행 주기(스케줄) 설정**:
   - 현재 **매주 월요일 저녁 19:00 KST (한국 시간)**에 실행되도록 설정되어 있습니다. (월요일 회의 후 저녁 7시에 자동 정리되어, 화요일 아침에 출근하여 바로 확인 가능!)
   - 스케줄 변경이 필요하다면 [`.github/workflows/weekly_sync.yml`](file:///.github/workflows/weekly_sync.yml) 파일의 `cron` 설정에서 시간을 변경하실 수 있습니다:
     - `cron: '0 10 * * 1'` -> 매주 월요일 저녁 19:00 KST (기본값)
     - `cron: '0 11 * * 1'` -> 매주 월요일 저녁 20:00 KST
     - `cron: '0 9 * * 1'` -> 매주 월요일 저녁 18:00 KST

---

### 방법 2: 내 컴퓨터(로컬)에서 직접 실행하기

1. **패키지 설치**:
   ```bash
   pip install -r requirements.txt
   ```
2. **환경 변수 파일 작성**:
   - `.env.example` 파일을 복사하여 `.env` 파일을 만들고 값을 입력합니다.
   ```bash
   cp .env.example .env
   # .env 파일을 열어 NOTION_TOKEN, PAGE_ID, GEMINI_API_KEY 등을 입력
   ```
3. **스크립트 실행**:
   ```bash
   python main.py
   ```

---

## 📂 파일 구조
```text
├── .github/
│   └── workflows/
│       └── weekly_sync.yml     # 매주 월요일 자동 실행 GitHub Actions
├── config.py                   # 환경 변수 로드 및 Notion URL/ID 유효성 검사기
├── notion_service.py           # Notion API 통신 (회의록 조회, 섹션 검색, 1열 표 생성 및 행 추가)
├── ai_service.py               # 회의록 AI 맥락 분석 및 액션 아이템 추출기 (Gemini/OpenAI 지원)
├── main.py                     # 자동화 실행 메인 파이프라인
├── test_mock_run.py            # 단위 테스트 코드
├── requirements.txt            # 필요 라이브러리 목록
├── .env.example                # 환경 변수 설정 예시
└── README.md                   # 상세 사용 설명서
```
