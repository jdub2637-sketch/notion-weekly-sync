import unittest
from config import clean_notion_id
from ai_service import AIService
from notion_service import NotionService

class TestNotionSync(unittest.TestCase):

    def test_clean_notion_id(self):
        # 1. URL 형식
        url1 = "https://www.notion.so/myworkspace/Marketing-Weekly-Meeting-2b9921e6955a40a8a68b7dc3f639ea07"
        self.assertEqual(clean_notion_id(url1), "2b9921e6955a40a8a68b7dc3f639ea07")

        # 2. 쿼리스트링이 붙은 URL
        url2 = "https://www.notion.so/Daily-Life-1234567890abcdef1234567890abcdef?pvs=4"
        self.assertEqual(clean_notion_id(url2), "1234567890abcdef1234567890abcdef")

        # 3. 하이픈이 포함된 UUID
        uuid_str = "12345678-90ab-cdef-1234-567890abcdef"
        self.assertEqual(clean_notion_id(uuid_str), "1234567890abcdef1234567890abcdef")

        # 4. 순수 32자리 ID
        pure_id = "1234567890abcdef1234567890abcdef"
        self.assertEqual(clean_notion_id(pure_id), "1234567890abcdef1234567890abcdef")

        # 5. Notion 최신 공유 링크 형식 (pvs=4, # 등)
        share_url = "https://www.notion.so/my-team/Weekly-Meeting-2b9921e6955a40a8a68b7dc3f639ea07#heading-1"
        self.assertEqual(clean_notion_id(share_url), "2b9921e6955a40a8a68b7dc3f639ea07")

    def test_ai_task_parser(self):
        ai = AIService(provider="gemini", gemini_api_key="test")
        sample_output = """
        1. [콘텐츠] 인스타그램 릴스 2건 기획 및 촬영
        - [퍼포먼스] 메타 광고 소재 A/B 테스트 세팅 (수요일까지)
        * [데이터] 지난주 프로모션 전환율 대시보드 업데이트
        """
        tasks = ai._parse_tasks(sample_output)
        self.assertEqual(len(tasks), 3)
        self.assertEqual(tasks[0], "[콘텐츠] 인스타그램 릴스 2건 기획 및 촬영")
        self.assertEqual(tasks[1], "[퍼포먼스] 메타 광고 소재 A/B 테스트 세팅 (수요일까지)")
        self.assertEqual(tasks[2], "[데이터] 지난주 프로모션 전환율 대시보드 업데이트")

    def test_notion_plain_text_extractor(self):
        notion = NotionService(token="test")
        rich_text = [
            {"plain_text": "WorkNote("},
            {"plain_text": "Short-term)"}
        ]
        self.assertEqual(notion.extract_plain_text(rich_text), "WorkNote(Short-term)")

    def test_extract_inline_codes(self):
        notion = NotionService(token="test")
        # Control + E 가 적용된 블록 모의 데이터
        mock_block = {
            "type": "bulleted_list_item",
            "bulleted_list_item": {
                "rich_text": [
                    {
                        "type": "text",
                        "plain_text": "이번 주 업무: ",
                        "annotations": {"code": False}
                    },
                    {
                        "type": "text",
                        "plain_text": "[퍼포먼스] 메타 광고 A/B 테스트 세팅",
                        "annotations": {"code": True}  # Control + E
                    },
                    {
                        "type": "text",
                        "plain_text": " 및 ",
                        "annotations": {"code": False}
                    },
                    {
                        "type": "text",
                        "plain_text": "[콘텐츠] 카드뉴스 2건 발행",
                        "annotations": {"code": True}  # Control + E
                    }
                ]
            }
        }
        extracted = notion.extract_inline_codes_from_block(mock_block)
        self.assertEqual(len(extracted), 2)
        self.assertEqual(extracted[0], "[퍼포먼스] 메타 광고 A/B 테스트 세팅")
        self.assertEqual(extracted[1], "[콘텐츠] 카드뉴스 2건 발행")

if __name__ == "__main__":
    unittest.main()
